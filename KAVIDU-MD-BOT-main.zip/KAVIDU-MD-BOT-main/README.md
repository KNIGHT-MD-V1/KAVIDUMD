

![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=F01&lines=KAVIDU+ＭＤ+V1+ＷＨＡＴＳＡＰＰ+ＢＯＴ)

![Image Alt](https://i.ibb.co/Z12ByPbd/9307.jpg)


<h1 align="center">Hi 👋, I'm KAVIDU-MD V1</h1>


